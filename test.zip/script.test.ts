// script.test.ts
import { assertEquals } from "https://deno.land/std/testing/asserts.ts";

Deno.test("Simple test", () => {
  assertEquals("hello", "hello");
});